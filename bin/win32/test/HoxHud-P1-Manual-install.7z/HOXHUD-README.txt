﻿██╗  ██╗ ██████╗ ██╗  ██╗██╗  ██╗██╗   ██╗██████╗     ██████╗  ██╗
██║  ██║██╔═══██╗╚██╗██╔╝██║  ██║██║   ██║██╔══██╗    ██╔══██╗███║
███████║██║   ██║ ╚███╔╝ ███████║██║   ██║██║  ██║    ██████╔╝╚██║
██╔══██║██║   ██║ ██╔██╗ ██╔══██║██║   ██║██║  ██║    ██╔═══╝  ██║
██║  ██║╚██████╔╝██╔╝ ██╗██║  ██║╚██████╔╝██████╔╝    ██║      ██║
╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝     ╚═╝      ╚═╝

Installation Guide:
1: Extract ALL the files from the .7z without modifying the structure. You can of course omit this README, but nothing else.
2: Go to steamapps\common\Payday 2 and put the contents there.
3: Launch Payday 2.
3b: If it crashes/doesn't launch download the VC redist file below.

Make sure you have joined HoxHud Public Group or HoxHud will 
not be active while playing.

http://www.microsoft.com/en-us/download/details.aspx?id=40784
32 bit Windows users download and install the x86 version in the link above
64 bit Windows users download and install both x86 and x64.

A large portion of the Hud can be modified via the HoxHudTweakData file located in the
HoxHud folder of your Install; Hud Timer Displays, Numeric Timers,
Interaction Circles, Numeric displays for Ammo, Colors of most Hud elements, adding and
removal of certain features, and much more. 
If you need help configuring it try asking people in the group chat.

Bugs can be posted in the discussion for them in the HoxHud group, and if you
have any other questions try asking in the group chat.
